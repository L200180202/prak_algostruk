def cetakSiku(x):
    for i in range(x+1):
        print (i * "*")
