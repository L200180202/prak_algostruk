from Modul2.LatOOP4 import *

class MhsTIF(Mahasiswa):
    """Class MhsTIF yang dibangun dari class Mahasiswa"""
    def katakanPy(self):
        print('Python is cool.')

#SOAL NO7
#NIM berasal dari class Mahasiswa
#ambilNIM berasal dari class Mahasiswa
#ambilNama berasal dari class Mahasiswa
#ambilUangSaku berasal dari class Mahasiswa
#katakanPy berasal dari class MhsTIF
#keadaan berasal dari class Manusia
#kotaTinggal berasal dari class Mahasiswa
#makan berasal dari class Manusia
#mengalikanDenganDua berasal dari class Manusia
#nama berasal dari class Mahasiswa dan Manusia
#listKuliah berasal dari class Mahasiswa
#ambilKuliah berasal dari class Mahasiswa
#hapusKuliah berasal dari class Mahasiswa
#tambahUangSaku berasal dari class Mahasiswa
#uangSaku berasal dari class Mahasiswa
#ambilKotaTinggal dari class Mahasiswa
#olahraga berasal dari class Manusia
#perbaruiKotaTinggal berasal dari class Mahasiswa
#ucapkanSalam berasal dari class Manusia